<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/

/**
 * LOCKING
 */
class Locking
{
	// Array of record-event-fields that are locked in a project
	public $locked = array();

	// Get array of all record-event-fields that are locked in a project, and add to $locked array
	public function findLocked($Proj, $records=array(), $fields=array(), $events=array())
	{
		// Build SQL
		$project_id = $Proj->project_id;
        if (!is_array($events)) $events = array($events);
        $eventSql = empty($events) ? "" : " and l.event_id in (".prep_implode($events).")";
		if (!is_array($records)) $records = array($records);
        $sql_records = empty($records) ? "" : " and l.record in (".prep_implode($records).")";
		if (!is_array($fields)) $fields = array($fields);
        $sql_fields = empty($fields) ? "" : " and m.field_name in (".prep_implode($fields).")";
		## LOCKING CHECK: Get all forms that are locked for the uploaded records
		$sql = "select l.record, l.event_id, l.instance, m.field_name, m.element_type, m.element_enum
				from redcap_locking_data l, redcap_metadata m
				where m.project_id = $project_id $recordSql $eventSql $fieldSql
				and l.project_id = m.project_id and m.form_name = l.form_name";
        // Deal with long queries
        if (strlen($sql.$sql_fields) > 1000000) {
            $checkFieldNameEachLoop = true;
        } else {
            $sql .= $sql_fields;
            $checkFieldNameEachLoop = false;
        }
        if (strlen($sql.$sql_records) > 1000000) {
            $checkRecordNameEachLoop = true;
        } else {
            $sql .= $sql_records;
            $checkRecordNameEachLoop = false;
        }
		$locked = array();
		$q = db_query($sql);
		while ($row = db_fetch_assoc($q))
		{
            // If we need to validate the field name in each loop, then check.
            if ($checkFieldNameEachLoop && !in_array($row['field_name'], $fields)) continue;
            // If we need to validate the record in each loop, then check.
            if ($checkRecordNameEachLoop && !in_array($row['record'], $records)) continue;

			if ($row['element_type'] == 'checkbox') {
				foreach (array_keys(parseEnum($row['element_enum'])) as $this_code) {
					$chkbox_field_name = $row['field_name'] . "___" . Project::getExtendedCheckboxCodeFormatted($this_code);
					$this->locked[$row['record']][$row['event_id']][$row['instance']][$chkbox_field_name] = "";
				}
			} else {
				$this->locked[$row['record']][$row['event_id']][$row['instance']][$row['field_name']] = "";
			}
		}
	}

}
