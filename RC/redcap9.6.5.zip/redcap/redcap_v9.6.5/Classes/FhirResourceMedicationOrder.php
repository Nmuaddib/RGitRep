<?php
namespace {

    class FhirResourceMedicationOrder extends FhirResourceEntry
    {

        /**
         * name of the endpoint
         */
        const RESOURCE_NAME = 'MedicationOrder';

        /**
         * list of possible status for a medication
         */
        const STATUS_ACTIVE = 'active';
        const STATUS_COMPLETED = 'completed';
        const STATUS_ON_HOLD = 'on-hold';
        const STATUS_STOPPED = 'stopped';

        /**
         * doses
         * 
         * @var \FhirResourceMedicationOrder\Dosage[] $doses
         */
        private $doses = array();

         
        /**
         * codings
         *
         * @var FhirResourceCoding[]
         */
        private $codings = array();

        public function __construct($params)
        {
            parent::__construct($params);
            $this->doses = $this->setDoses();
            $this->codings = $this->setCodings();
        }

        public static function getSearchUrl($params = array())
        {
            /**
             * set the status to retrieve from the endpoint
             * default status is active
             * available status are: active, completed, on-hold, stopped
             */
            // $status_list = array('active', 'completed', 'on-hold', 'stopped');

            $status_list = isset($params['status']) ? $params['status'] : array(static::STATUS_ACTIVE);
            if(!is_array($status_list)) $status_list = explode(',', $status_list); // make sure status_list is an array
            unset($params['status']);
            $url = parent::getSearchUrl($params);
            $status = implode(',', $status_list);
            $url .= sprintf("&status=%s", $status);
            return $url;
        }

        public function getDoses()
        {
            return $this->doses;
        }
        
        protected function setDoses()
        {
            $doses = array();
            $dosageInstructions = $this->dosageInstruction;
            foreach ($dosageInstructions as $dosageInstruction)
            {
                $doses[] = new \FhirResourceMedicationOrder\Dosage($dosageInstruction);
            }
            return $doses;
        }

        public function getCodings()
        {
            return $this->codings;
        }
        
        protected function setCodings()
        {
            $values = $this->search('medicationCodeableConcept.coding[]');
            if(empty($values)) return array();
            $codings = array_map(function($coding) {
                return new \FhirResourceCoding($coding);
            }, $values);
            return $codings;
        }

        /**
         * get the medication name
         * the name could be stored in different locations
         *
         * @return string
         */
        public function getText()
        {
            $expressions = array(
                "medicationReference.display",
                "medicationCodeableConcept.text",
            );
            foreach ($expressions as $expression) {
                $value = $this->search($expression);
                if(!empty($value)) return $value;
            }
            return '';
        }

        public function getLongText()
        {
            
            $timestamp = $this->getFormattedDate();
            $status = $this->getStatus();

            // helper function to get a list of strings from the codings
            $getCodingList = function($codings) {
                $codes_list = array();
                foreach($codings as $coding)
                {
                    $display = $coding->getDisplay();
                    $code_text = array();
                    if($system = $coding->getSystem()) $code_text[] = $system;
                    if($code = $coding->getCode()) $code_text[] = $code;
                    if(empty($code_text))
                    {
                        // cody has only display available
                        $codes_list[] = $display;
                    }else
                    {
                        // we also have code and/or system; show them in parenthesis
                        $codes_list[] = sprintf("%s (%s)", $display, implode(" ", $code_text));
                    }
                }
                return $codes_list;
            };
            $codes_list = $getCodingList($this->getCodings());
            if(empty($codes_list))
            {
                // if there are no codings then use the generic text
                $display = $this->getText();
            }else
            {
                // use all codes available
                $display = implode(', ', $codes_list);
            }
            
            $doses = $this->getDoses(); // get the doses for the current medication
            $firstDose = reset($doses); // get the first dose
            $dosage = ($firstDose instanceof \FhirResourceMedicationOrder\Dosage) ? $firstDose->getText() : '';
            // compose the text to display in CDP
            $text_values = array();
            if(!empty($display)) $text_values[] = $display;
            if(!empty($dosage)) $text_values[] = $dosage;
            $text_values = array(implode(', ', $text_values)); // join text values and store back in array
            if(!empty($status)) $text_values[] = $status;
            if(!empty($timestamp)) $text_values[] = $timestamp;
            $text = implode(' - ', $text_values); // join text and date
            $text = trim($text);
            return $text;
        }
        
        /**
         * return when the medication was written
         *
         * @return string
         */
        public function getDate()
        {
            $value = $this->search('dateWritten');
            return $value;
        }

        public function getFormattedDate($format='Y-m-d')
        {
            $date = $this->getDate();
            if(empty($date)) return;
            $dateTime = new DateTime($date);
            return $dateTime->format($format);
        }
        
        /**
         * get the status
         * if the status is empty return the default status (active)
         *
         * @return string
         */
        public function getStatus()
        {
            $value = $this->search('status');
            return $value;
        }

        public function getData()
        {
            $doses = $this->getDoses();
            $dosageInstructions = array_map(function($dose) {
                return $dose->getTiming();
            }, $doses);

            $data = array(
                'text' => $this->getText(),
                'date' => $this->getFormattedDate(),
                'dosage_instruction' => implode(', ', $dosageInstructions),
                'prescriber' => $this->prescriber->display,
                'status' => $this->status,
                'doses' => $doses,
            );
            return $data;
        }

        public function __toString()
        {
            return $this->getLongText();
        }
    }
}

namespace FhirResourceMedicationOrder {

    /**
     * Medication dosage
     * 
     * @property FhirResourceMedicationOrder\Dosage\Route $route
     */
    class Dosage extends \FhirResource
    {

        const REPEAT_PERIOD_START = 'start';
        const REPEAT_PERIOD_END = 'end';

        public function __construct($params)
        {
            parent::__construct($params);
            $this->route = $this->getRoute();
        }

        protected function getRoute()
        {
            $route = new \FhirResourceMedicationOrder\Dosage\Route($this->route);
            return $route;
        }

        public function getText()
        {
            $expressions = array(
                "text",
                "timing.code.text",
            );
            foreach($expressions as $expression)
            {
                $value = $this->search($expression);
                if(!empty($value)) return $value;
            }
            return '';
        }

        public function getTiming()
        {
            return $this->search('timing');
        }

        public function getQuantity()
        {
            $value = $this->search('doseQuantity.value');
            $unit = $this->search('doseQuantity.unit');
            return sprintf("%s %s", $value, $unit);
        }

        /**
         * get repeat instructions
         *
         * @param string $period start|end
         * @return void
         */
        public function getRepeat($period=self::REPEAT_PERIOD_START)
        {
            $periods = array(self::REPEAT_PERIOD_START, self::REPEAT_PERIOD_END);
            if(!in_array($period, $periods)) return '';
            $expression = sprintf("timing.repeat.boundsPeriod.%s", $period);
            $value = $this->search($expression);
            return $value;
        }


        public function getAsNeeded()
        {
            return $this->search('asNeededBoolean');
        }

        public function getData()
        {
            $data = array(
                'asNeeded' => $this->getAsNeeded(),
                'quantity' => $this->getQuantity(),
                'route' => $this->getRoute(),
                'timing' => $this->getTiming(),
                'text' => $this->getText(),
                'repeat_start' => $this->getRepeat(self::REPEAT_PERIOD_START),
                'repeat_end' => $this->getRepeat(self::REPEAT_PERIOD_END),
            );
            return array_merge(parent::getData(), $data);
        }

        /**
         * get JSON serialized version of the object
         *
         * @return array
         */
        public function jsonSerialize()
        {
            
            return $this->getData();
        }

    }

}

namespace FhirResourceMedicationOrder\Dosage {
    
    class Route extends \FhirResource
    {
        public function __construct($params)
        {
            parent::__construct($params);
            // override the default path of the coding systems
            $this->coding_systems = $this->search('coding');
        }

        public function getText()
        {
            return $this->search('text');
        }

        public function getData()
        {
            $data = array(
                'text' => $this->getText(),
            );
            return $data;
        }

        /**
         * get JSON serialized version of the object
         *
         * @return array
         */
        public function jsonSerialize()
        {
            
            return $this->getData();
        }
    }
}