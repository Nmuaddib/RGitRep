<?php
/**
 * class for a FHIR resource boudle
 */
class FhirResourcePatient extends FhirResource
{
    /**
     * name of the endpoint
     */
    const RESOURCE_NAME = 'Patient';

    /**
     * get the expression used to retrieve the name
     *
     * @param string $type
     * @return void
     */
    public function getName($type='family')
    {
		// get the usual or official name | only the first result | join values using blank space
        $expression = sprintf("name[?use == 'usual' || use == 'official'] | [0].%s | join(' ', @)", $type);
        return $this->search($expression);
    }

    /**
     * get given name
     *
     * @return string
     */
    public function getNameGiven()
    {
        $value = $this->getName('given');
        return $value;
    }

    /**
     * get family name
     *
     * @return string
     */
    public function getNameFamily()
    {
        $value = $this->getName('family');
        return $value;
    }

    /**
     * get birthdate
     *
     * @return string
     */
    public function getBirthDate()
    {
        return $this->search('birthDate');
    }

    /**
     * get the valueCode of an extensione with url ending with $url_ending |
	 * get the first value
     *
     * @param string|array $url_ending
     * @return string
     */
    private function getExtensionCode($url_ending)
    {
        if(!is_array($url_ending)) $url_ending = array($url_ending);
        $ends_with = array();
        foreach ($url_ending as $ending) {
            $ends_with[] = sprintf("ends_with(url, '%s')", $ending);
        }
        $filter = implode(' || ', $ends_with);
        $expressions = array(
            /**
             * get extensione with url ending with $url_ending |
	         * get a valueCodeableConcept with a coding system |
	         * get the code | get the first value
             */
            'coding_code' => sprintf("extension[?%s] |
					                [?valueCodeableConcept.coding[].system] |
                                    [].valueCodeableConcept.coding[].code | [0]", $filter),
            'valueCode' => sprintf("extension[?%s].valueCode | [0]", $filter),
        );
        foreach ($expressions as $expression)
        {
            $value = $this->search($expression);
            if(!empty($value)) return $value;
        }
        return '';
    }

    /**
     * get the valueCode of an extensione with url ending with $url_ending |
	 * get the first value
     *
     * @param string|array $url_ending
     * @return string
     */
    private function getExtensionText($url_ending)
    {
        if(!is_array($url_ending)) $url_ending = array($url_ending);
        $ends_with = array();
        foreach ($url_ending as $ending) {
            $ends_with[] = sprintf("ends_with(url, '%s')", $ending);
        }
        $filter = implode(' || ', $ends_with);
        $expressions = sprintf("extension[?%s].valueCodeableConcept.text | [0]", $filter);
        $value = $this->search($expressions);
        return $value;
    }

    public function getRace($code=true)
    {
        $url_ending = '-race';
        if($code) return $this->getExtensionCode($url_ending);
        return $this->getExtensionText($url_ending);
    }

    public function getGender($code=true)
    {
        $url_ending = array('-birth-sex', '-birthsex');
        if($code) return $this->getExtensionCode($url_ending);
        return $this->getExtensionText($url_ending);
    }

    public function getEthnicity($code=true)
    {
        $url_ending = '-ethnicity';
        if($code) return $this->getExtensionCode($url_ending);
        return $this->getExtensionText($url_ending);
    }

    public function isDeceased()
    {
        return $this->search('deceasedBoolean');
    }

    public function getEmail()
    {
        $expression = "telecom[?system=='email'].value";
        $emails = $this->search($expression);
        return implode('; ', $emails);
    }

    /**
     * get a specific field of an address
     * the address is filtered with the $use parameter
     *
     * @param string $type
     * @param string $use
     * @return string
     */
    public function getAddress($type, $use='home')
    {
        $expression = sprintf("address[?use=='%s'].%s | [0]", $use, $type);
        $value = $this->search($expression);
        if(is_array($value)) $value = implode(', ', $value);
        return $value;
    }

    public function getAddressLine()
    {
        return $this->getAddress('line');
    }

    public function getAddressCity()
    {
        return $this->getAddress('city');
    }

    public function getAddressState()
    {
        return $this->getAddress('state');
    }

    public function getAddressPostalCode()
    {
        return $this->getAddress('postalCode');
    }

    public function getAddressCountry()
    {
        return $this->getAddress('country');
    }


    public function getPhone($type)
    {

        // PHONE
        $phoneSystems = array('home', 'mobile');
        foreach ($phoneSystems as $phoneSystem)
        {
            $expression = sprintf("telecom[?system=='phone'] | [?use=='%s'].value | [0]", $type);
            $value = $this->search($expression);
            if(is_array($value)) $value = implode(', ', $value);
            return $value;
        }
    }

    public function getPhoneHome()
    {
        return $this->getPhone('home');
    }
    public function getPhoneMobile()
    {
        return $this->getPhone('home');
    }

    /**
     * get all data available for this resource
     *
     * @return array
     */
    public function getData()
    {
        $data = array(
            'first_name' => $this->getNameGiven(),
            'last_name' => $this->getNameFamily(),
            'gender' => $this->getGender(false),
            'gender_code' => $this->getGender(),
            'ethnicity' => $this->getEthnicity(false),
            'ethnicity_code' => $this->getEthnicity(),
            'race' => $this->getRace(false),
            'race_code' => $this->getRace(),
            'birthdate' => $this->getBirthDate(),
            'address_city' => $this->getAddressCity(),
            'address_country' => $this->getAddressCountry(),
            'address_postal_code' => $this->getAddressPostalCode(),
            'address_state' => $this->getAddressState(),
            'address_line' => $this->getAddressLine(),
            'phone_home' => $this->getPhoneHome(),
            'phone_mobile' => $this->getPhoneMobile(),
            'email' => $this->getEmail(),
            'is_deceased' => $this->isDeceased(),
        );
        return $data;
    }
}