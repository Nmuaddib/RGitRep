<?php
/**
 * class for a FHIR resource boudle
 */
class FhirResourceOperationOutcome extends FhirResource
{


    public function getIssues()
    {
        $issues = $this->search('issue');
        if(!is_array($issues)) $issues = array();
        return $issues;
    }

    public function getSeverity()
    {
        return $this->search('issue[].severity');
    }

    public function getCode()
    {
        return $this->search('issue[].code');
    }

    public function getText()
    {
        return $this->search('issue[].details.text');
    }

    /**
     * get all data available for this resource
     *
     * @return array
     */
    public function getData()
    {
        $data = array(
            'severity' => $this->getSeverity(),
            'code' => $this->getCode(),
            'text' => $this->getText(),
        );
        return $data;
    }
}