<?php

/**
 * @method string revisions()
 * @method string getUser()
 * @method string addRevision()
 * @method string deleteRevision()
 * @method string exportRevision()
 * @method string importRevision()
 * @method string sourceFields()
 * @method string runRevision()
 * @method string approveRevision()
 * @method void index()
 */
class DataMartController extends BaseController {

    /**
     * maximum number of simultaneous revisions per hour
     */
    const MAX_REVISIONS_PER_HOUR = 10;

    /**
     * instance of the model
     *
     * @var DataMart
     */
    private $model;

    /**
     * list of allowed routes with request types
     *
     * @var array
     */
    protected $routes = array(
        'index' => array('GET'), // main page
        'revisions' => array('GET'), // get all revisions
        'getUser' => array('GET'), // get DataMart user
        'sourceFields' => array('GET'), // get source fields
        'addRevision' => array('POST'), // add a revision (and submit a revision request)
        'runRevision' => array('POST'), // run a revision
        'approveRevision' => array('POST'), // approve a revision
        'deleteRevision' => array('DELETE'), // delete a revision
        'exportRevision' => array('GET'), // export a revision
        'importRevision' => array('POST'), // import a revision
    );

    public function __construct()
    {
        parent::__construct();
        // $this->enableCORS();
        $this->model = new DataMart();
    }

    /**
     * route, get a list of revisions
     *
     * @return string json response
     */
    private function revisions()
    {
        $project_id = $_REQUEST['pid'];
        if($request_id = $_REQUEST['request_id'])
        {
            $revision = $this->model->getRevisionFromRequest($request_id);
            if(!$revision)
            {
                $error = new JsonError(
                    $title = 'revision not found',
                    $detail = sprintf("no revision associated to the request ID %s has been found", $request_id),
                    $status = 400,
                    $source = PAGE // get the current page
                );
                $this->printJSON($error, $status_code=400);
            }
            $response = array($revision);
        }else
        {
            $response = $this->model->getRevisions($project_id);
        }
        $this->printJSON($response, $status_code=200);
    }

    /**
     * route, get the user
     *
     * @return string json response
     */
    private function getUser()
    {
        global $userid;
        /* 
         * static version
        $modelClassName = get_class($this->model);
        $response =   call_user_func_array(array($modelClassName, "getUserInfo"), array($this->username, $this));
        */


        $project_id = $_REQUEST['pid'];
        $response =   $this->model->getUser($userid, $project_id);
        $this->printJSON($response, $status_code=200);
    }

    /**
     * add a revision
     *
     * @return string
     */
    private function addRevision()
    {
        $settings = array(

            'project_id'    => $_REQUEST['pid'],
            'request_id'    => $_REQUEST['request_id'],
            'mrns'          => $_REQUEST['mrns'],
            'fields'        => $_REQUEST['fields'],
            'date_min'      => $_REQUEST['date_min'],
            'date_max'      => $_REQUEST['date_max'],
        );
        $response = $this->model->addRevision($settings);
        if($response==true)
            $this->printJSON($response, $status_code=200);
        else
            $this->printJSON($response, $status_code=400);
    }

    /**
     * delete a revision
     *
     * @return void
     */
    private function deleteRevision()
    {
        // gete the data from the DELETE method
        $data = file_get_contents("php://input");
        parse_str($data, $params);
        $id = $params['revision_id'];
        $deleted = $this->model->deleteRevision($id);
        if($deleted==true)
        {
            $response = array('data'=>array('id'=>$id));
            $this->printJSON($response, $status_code=200);
        } else
        {
            // typical structure for a json object
            $error = new JsonError(
                $title = 'Revision not deleted',
                $detail = sprintf("The revision ID %u could not be deleted.", $id ),
                $status = 400,
                $source = PAGE
            );
            $this->printJSON($error, $status_code=400);
        }
    }
    /**
     * export a revision
     *
     * @return void
     */
    private function exportRevision()
    {
        $revision_id = $_REQUEST['revision_id'];
        $format = isset($_REQUEST['format']) ? $_REQUEST['format'] : 'csv';
        $csv_delimiter = isset($_REQUEST['csv_delimiter']) ? $_REQUEST['csv_delimiter'] : ",";
        $fields = isset($_REQUEST['fields']) ? $_REQUEST['fields'] : array();
        $this->model->exportRevision($revision_id, $fields, $format, $csv_delimiter);
    }

    /**
     * parse a file for a revision
     *
     * @return string
     */
    private function importRevision()
    {
        $uploaded_files = FileManager::getUploadedFiles();
        $files = $uploaded_files['files'];
        $file = reset($files); // get the first element in the array of files
        if($file)
        {
            $data = $this->model->importRevision($file);
            $this->printJSON($response=array('data' => $data), $status_code=200);
        }else
        {
            $error = new JsonError(
                $title = 'no file to process',
                $detail = 'A file must be provided to import a revision',
                $status = 400,
                $source = PAGE // get the current page
            );
            $this->printJSON($error, $status_code=400);
        }
    }

    /**
     * get the sourcefields
     *
     * @return void
     */
    private function sourceFieldsOriginal()
    {
        $response = $this->model->getSourceFields();
        $this->printJSON($response, $status_code=200);
    }
    /**
     * get the sourcefields
     *
     * @return string
     */
    private function sourceFields()
    {
        $fields = $this->model->getExternalFields();
        $response = array('data' => $fields);
        $this->printJSON($response, $status_code=200);
    }

    /**
     * helper function that sends an error response if the maximum
     * number of requests for a page has been reached
     *
     * @param integer $limit
     * @return string|null
     */
    private function throttle($limit=10)
    {
        $page = PAGE; // get the current page
        $throttler = new Throttler();
        
        if($throttler->throttle($page, $limit))
        {
            // typical structure for a json object
            $error = new JsonError(
                $title = 'Too Many Requests',
                $detail = sprintf('The maximum of %u simultaneus request%s has been reached. Try again later.', $limit, $singular=($limit===1) ? '' : 's' ),
                $status = Throttler::ERROR_CODE,
                $source = PAGE
            );

            $this->printJSON($error , $status_code=$status);
        }
    }

    /**
     * method for testing the throttle
     *
     * @return string
     */
    private function throttleTest()
    {
        $this->throttle(1); //limit to a maximum of 1
        sleep(10);
        $this->printJSON(array('success' => true, 'errors'=>array()), $status_code=200);
    }

    /**
     * run a revision
     *
     * @return string
     */
    private function runRevision()
    {
        $this->throttle(self::MAX_REVISIONS_PER_HOUR);

        $id = $_POST['revision_id'];
        $request_id = $_POST['request_id'];
        try {
            $response = $this->model->runRevision($id, $request_id);
            $this->printJSON($response, $status_code=200);
        } catch (\Exception $e) {
            $error = new JsonError(
                $title = 'Cannot run the revision',
                $detail = $e->getMessage(),
                $status = $e->getCode(),
                $source = PAGE
            );
            $this->printJSON($error, $status_code=$e->getCode());
        }
    }

    /**
     * approve a revision
     *
     * @return string
     */
    private function approveRevision()
    {
        $id = $_REQUEST['revision_id'];
        $revision = $this->model->approveRevision($id);
        if($revision)
        {
            $response = array('data'=>$revision);
            $this->printJSON($response, $status_code=200);
        }else
        {
            $error_code = 401; //unauthorized
            $error = new JsonError(
                $title = 'Revision not approved',
                $detail = sprintf("The revision ID %u could not be approved.", $id),
                $status = $error_code,
                $source = PAGE
            );
            $this->printJSON($error, $status_code=$error_code);
        }
    }

    private function index()
    {
        extract($GLOBALS);
        include APP_PATH_DOCROOT . 'ProjectGeneral/header.php';
        if ($isIE && vIE() <= 10) : ?>
            <h3>
                <i class="fas fa-exclamation-triangle"></i>
                <span>This feature is not available for your browser.</span>
            </h3>
        <?php elseif (DataMart::isEnabled($project_id)) : ?>
            <div id="datamart-target"></div>
            <script src="<?php echo APP_PATH_JS ?>DataMart/dist/main.js"></script>
            <!-- <script src="https://localhost:8080/main.js"></script> -->
            <script type="text/javascript">
                (function (window, document) {
                    /* var translations = {
                        'step1': "<?php print js_escape2($lang['data_mart_refresh_001']) ?>",
                        'step2': "<?php print js_escape2($lang['data_mart_refresh_002']) ?>",
                        'step3': "<?php print js_escape2($lang['data_mart_refresh_003']) ?>",
                    } */
                    if (window._DATAMART_) {
                        var target = document.getElementById("datamart-target");
                        var datamart = new _DATAMART_({target: target});
                        window.dataMart = datamart
                    }
                }(window, document));
            </script>
        <?php else :?>
            <h3>
                <i class="fas fa-info-circle"></i>
                <span>This is not a Datamart Project!</span>
            </h3>
        <?php endif;
        include APP_PATH_DOCROOT . 'ProjectGeneral/footer.php';
    }

}