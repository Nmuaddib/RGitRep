package org.projectredcap.main;

public class Config
{
	final String API_SUPER_TOKEN = "ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234";
	final String API_TOKEN = "29344DCA67C497BCFAAC7147AA7E3790";
	final String API_URL = "http://example.com/redcap/api/";
}
